.. _intro-examples:

========
Examples
========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   notebooks/glasspy_data
   notebooks/glasspy_predict
